import "./Css/CssContent/Sobre.css"

export default function Sobre(){

    return(
        <div className="base-sobre">
            <div className="sobre">
                <h2>Integrantes do grupo</h2>  
                <ul>
                    <li>93419 - Thiago Miguel Lapazini</li>
                    <li>95177 - Lucas Vinicius Oliveira Galindo</li>
                    <li>95224 - Leonard Karic Klovrza</li>
                    <li>95438 - José Vitor Brasilino da Silva</li>
                    <li>93298 - Paola Mendes Bernardes</li>
                </ul>
            </div>
        </div>
    )
}

